<?php
// Arquivo: teste_db.php

require_once 'config.php';
use MongoDB\BSON\UTCDateTime;
use MongoDB\BSON\ObjectId;

// Documento de teste com um ID único para garantir que só ele será removido
$testeId = new ObjectId(); 
$documentoTeste = [
    '_id' => $testeId,
    'nome' => 'Estudante de Teste',
    'timestamp' => new UTCDateTime()
];

echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><title>Teste MongoDB</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head><body><div class="container mt-5">';
echo '<h1>Teste de Conexão e CRUD Rápido no MongoDB Atlas</h1>';

// 1. Testa a Conexão Geral
if (!testConnection()) {
    die('<div class="alert alert-danger">❌ ERRO FATAL: Falha na conexão de rede. Verifique seu IP no Atlas.</div></div></body></html>');
}

try {
    $client = getMongoClient();
    $collection = $client->selectCollection(DB_NAME, COLLECTION_ESTUDANTES);

    // --- TESTE 1: INSERÇÃO (WRITE) ---
    $resultadoInsert = $collection->insertOne($documentoTeste);
    echo '<div class="alert alert-success">✅ Teste 1 (WRITE): Documento de teste inserido com ID: ' . $resultadoInsert->getInsertedId() . '</div>';

    // --- TESTE 2: BUSCA (READ) ---
    $documentoEncontrado = $collection->findOne(['_id' => $testeId]);
    if ($documentoEncontrado) {
        echo '<div class="alert alert-success">✅ Teste 2 (READ): Documento encontrado com sucesso.</div>';
    } else {
        echo '<div class="alert alert-warning">⚠️ Teste 2 (READ): Documento não encontrado. Algo deu errado na busca.</div>';
    }

    // --- TESTE 3: EXCLUSÃO (DELETE) ---
    $resultadoDelete = $collection->deleteOne(['_id' => $testeId]);
    if ($resultadoDelete->getDeletedCount() === 1) {
        echo '<div class="alert alert-success">✅ Teste 3 (DELETE): Documento de teste removido com sucesso.</div>';
    } else {
        echo '<div class="alert alert-warning">⚠️ Teste 3 (DELETE): Falha ao remover o documento de teste.</div>';
    }
    
    echo '<hr><div class="alert alert-info"><strong>STATUS FINAL:</strong> Se todos os testes acima foram ✅ SUCESSO, sua implantação de dados (Read/Write) no MongoDB Atlas está OK!</div>';

} catch (\Exception $e) {
    echo '<div class="alert alert-danger">❌ ERRO DURANTE O TESTE CRUD: ' . $e->getMessage() . '</div>';
}

echo '</div></body></html>';
?>