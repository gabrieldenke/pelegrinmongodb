<?php
// Arquivo: listar_estudantes.php

require_once 'config.php';
// Importante: O driver do MongoDB retorna objetos BSON, não arrays PHP, por padrão.
// Para lidar com BSON, usaremos o método ->toArray() ou iteraremos sobre o objeto.
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Estudantes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container { max-width: 1000px; margin-top: 50px; }
        .table-responsive { max-height: 70vh; overflow-y: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4 text-center">Lista de Estudantes Cadastrados</h1>
        <p class="text-end">
            <a href="index.php" class="btn btn-primary">Voltar ao Cadastro</a>
        </p>
        
        <?php
        // 1. Conecta e Testa a Conexão
        if (!testConnection()) {
            echo '<div class="alert alert-danger">Erro: Conexão com o banco de dados Atlas falhou.</div>';
        } else {
            try {
                $client = getMongoClient();
                $collection = $client->selectCollection(DB_NAME, COLLECTION_ESTUDANTES);
                
                // 2. Busca todos os estudantes (Find)
                $estudantes = $collection->find([], [
                    'sort' => ['nome' => 1] // Ordena por nome
                ]);
        ?>

        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>Nascimento</th>
                        <th>Telefones</th>
                        <th>Endereço Principal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // 3. Itera sobre os resultados
                    $count = 0;
                    foreach ($estudantes as $estudante) { 
                        $count++;
                        
                        // Extração de dados embutidos
                        $telefonePrincipal = $estudante->telefones[0]->numero ?? 'N/A';
                        $endereco = $estudante->endereco;
                        $enderecoFormatado = "{$endereco->logradouro}, {$endereco->cidade}/{$endereco->estado}";
                        
                        // Formatação da Data
                        // O driver PHP do MongoDB retorna a data como objeto UTCDateTime
                        $dataNasc = $estudante->dataNascimento->toDateTime()->format('d/m/Y');
                        
                        // Criação do link de exemplo (para futuro CRUD: Editar/Excluir)
                        $estudanteId = $estudante->_id;

                        // Exibe a linha na tabela
                        echo "<tr>";
                        echo "<td>{$count}.</td>";
                        echo "<td>{$estudante->nome}</td>";
                        echo "<td>{$estudante->cpf}</td>";
                        echo "<td>{$dataNasc}</td>";
                        echo "<td>Celular: {$telefonePrincipal}</td>";
                        echo "<td>{$enderecoFormatado}</td>";
                        echo "</tr>";
                    } 
                    
                    if ($count === 0) {
                        echo '<tr><td colspan="6" class="text-center">Nenhum estudante encontrado.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <?php
            } catch (\Exception $e) {
                echo '<div class="alert alert-danger">Erro ao buscar dados: ' . $e->getMessage() . '</div>';
            }
        }
        ?>

    </div>
</body>
</html>