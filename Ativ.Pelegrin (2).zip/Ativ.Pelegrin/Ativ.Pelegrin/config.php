<?php
// config.php (corrigido)

declare(strict_types=1);

// Carrega o autoload do Composer (necessário para as classes do MongoDB)
$autoload = __DIR__ . '/vendor/autoload.php';
if (!file_exists($autoload)) {
    die("Erro: vendor/autoload.php não encontrado. Rode 'composer require mongodb/mongodb' na pasta do projeto.\n");
}
require_once $autoload;

use MongoDB\Client;
use MongoDB\Exception\Exception as MongoException;

// Use variável de ambiente se disponível (recomendado). Caso contrário, usa o valor abaixo.
// NÃO deixe credenciais em repositórios públicos.
$envUri = getenv('MONGODB_URI');
if ($envUri === false || $envUri === '') {
    // Substitua por sua URI apenas em ambiente local e com cuidado.
    define('MONGODB_URI', 'mongodb+srv://gabrieldenke_db_user:gabriel1234@cluster0.mongodb.net/?retryWrites=true&w=majority');
} else {
    define('MONGODB_URI', $envUri);
}

define('DB_NAME', 'catalogocursos');
define('COLLECTION_ESTUDANTES', 'estudantes');
define('COLLECTION_CURSOS', 'cursos');

/**
 * Retorna uma instância de MongoDB\Client
 *
 * @return Client
 * @throws RuntimeException em caso de falha
 */
function getMongoClient(): Client
{
    // Verifica se a extensão nativa do PHP está ativa
    if (!extension_loaded('mongodb')) {
        throw new \RuntimeException("A extensão PHP 'mongodb' não está habilitada. Instale/ative ext-mongodb (php_mongodb.dll) e reinicie o Apache/XAMPP.");
    }

    try {
        // Cria e retorna o cliente usando a URI definida
        return new Client(MONGODB_URI);
    } catch (MongoException $e) {
        // Exceção específica do MongoDB
        throw new \RuntimeException("Falha ao conectar ao MongoDB (MongoException): " . $e->getMessage(), 0, $e);
    } catch (\Throwable $e) {
        // Qualquer outro erro
        throw new \RuntimeException("Falha ao conectar ao MongoDB: " . $e->getMessage(), 0, $e);
    }
}

/**
 * Teste rápido de conexão ao servidor MongoDB (ping)
 *
 * @return bool
 */
function testConnection(): bool
{
    try {
        $client = getMongoClient();
        // executa ping no database admin
        $client->selectDatabase('admin')->command(['ping' => 1]);
        return true;
    } catch (\Throwable $e) {
        // Em ambiente de desenvolvimento você pode debugar com $e->getMessage()
        return false;
    }
}