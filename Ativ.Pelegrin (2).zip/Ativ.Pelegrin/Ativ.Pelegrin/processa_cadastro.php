<?php
// processa_cadastro.php
// Coloque este arquivo em: C:\xampp\htdocs\Ativ.Pelegrin\Ativ.Pelegrin\processa_cadastro.php
// Ajuste nomes de DB/coleção conforme necessário

require_once __DIR__ . '/config.php'; // carrega funções getMongoClient() e testConnection()

try {
    // 1) Cria cliente (pode passar URI customizado se quiser)
    $client = getMongoClient(); // usa o URI padrão definido em config.php

    // 2) Testa conexão — opcional, só para feedback
    $dbs = testConnection($client);
    echo "Conexão com MongoDB OK. Databases disponíveis: <br>";
    echo "<ul>";
    foreach ($dbs as $dbName) {
        echo "<li>" . htmlspecialchars($dbName) . "</li>";
    }
    echo "</ul>";

    // 3) Exemplo de inserção em uma coleção:
    // Defina seu DB/coleção
    $dbName = 'AtivPelegrinDB';      // ajuste para o nome real
    $collectionName = 'cadastros';   // ajuste para o nome real

    // Acesse coleção
    $collection = $client->selectCollection($dbName, $collectionName);

    // Document para inserir (exemplo)
    $document = [
        'nome' => 'João da Silva',
        'email' => 'joao@example.com',
        'created_at' => new MongoDB\BSON\UTCDateTime(), // timestamp MongoDB
    ];

    // Insere
    $result = $collection->insertOne($document);

    if ($result->getInsertedCount() === 1) {
        echo "Documento inserido com _id: " . (string) $result->getInsertedId();
    } else {
        echo "Inserção não reportou sucesso (insertedCount != 1).";
    }

} catch (Throwable $e) {
    // Mensagem de erro amigável (em produção remova detalhes sensíveis)
    echo "<h3>Erro:</h3>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    // Opcional: para debug completo, descomente:
    // echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
}
